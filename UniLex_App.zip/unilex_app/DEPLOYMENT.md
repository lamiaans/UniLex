# Deploying UniLex to Render

This deploys two separate services: the FastAPI backend and the static
frontend. They're separate so the frontend (just HTML/CSS/JS) deploys
instantly, while the backend (which needs to download an ML model) gets
its own build process.

## Option A — One click with render.yaml (recommended)

1. Push this whole repo to GitHub (you've already got `sara78606/UniLex` —
   make sure `backend/`, `frontend/`, and `render.yaml` are all in it, at
   the repo root).
2. Go to [dashboard.render.com](https://dashboard.render.com) → **New** →
   **Blueprint**.
3. Connect your GitHub account if you haven't, then select the `UniLex`
   repo. Render will read `render.yaml` automatically and show you both
   services (`unilex-api` and `unilex-frontend`) to create.
4. Click **Apply**. Render will:
   - Build the backend: install `requirements.txt`, download the spaCy
     model, then start uvicorn
   - Publish the frontend as a static site
5. Wait for both to finish deploying (the backend takes longer — a few
   minutes, mostly for the SBERT model download on first boot).
6. Copy the backend's URL (shown on its Render dashboard page, looks like
   `https://unilex-api.onrender.com`).
7. Edit `frontend/config.js` in your repo:
   ```js
   window.UNILEX_API_BASE = "https://unilex-api.onrender.com";
   ```
8. Commit and push that change — Render auto-redeploys the frontend.
9. Open the frontend's URL. Done.

## Option B — Manual setup (if you'd rather not use the Blueprint)

**Backend:**
1. New → Web Service → connect your repo
2. Root directory: `backend`
3. Build command: `bash build.sh`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Instance type: Free is fine for a class project (cold starts take
   30-60s after idling — mention this if you demo it live)

**Frontend:**
1. New → Static Site → connect your repo
2. Root directory: `frontend`
3. Build command: leave blank
4. Publish directory: `.` (the frontend folder itself)
5. After the backend is deployed, update `frontend/config.js` with its
   URL as in step 7 above, then redeploy the static site.

## Things worth knowing before you demo it

- **Free-tier cold starts:** Render's free web services spin down after
  15 minutes of inactivity and take ~30-60 seconds to wake back up on the
  next request. If you're demoing live, hit the API once a minute or two
  before your demo starts.
- **First request after a cold start is slower:** the SBERT model and its
  3,066 cached term embeddings load into memory on startup, not per-request,
  so this only affects the very first request after a cold start/restart,
  not every query.
- **CORS is wide open** (`allow_origins=["*"]`) in `main.py` — fine for a
  class project, but if this becomes a real product later, lock it down to
  your actual frontend's domain.
